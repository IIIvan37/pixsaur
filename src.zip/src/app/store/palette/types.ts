import { Vector } from '@/libs/pixsaur-color/src/type'

export type PaletteSlot = {
  color: Vector | null
  locked: boolean
}
