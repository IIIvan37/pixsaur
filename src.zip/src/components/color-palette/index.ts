export * from './color-palette-view'
