export * from './slider'
export { default } from './slider'
